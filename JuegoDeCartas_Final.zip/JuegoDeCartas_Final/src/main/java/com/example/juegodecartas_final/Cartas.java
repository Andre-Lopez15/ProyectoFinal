package com.example.juegodecartas_final;
    public class Cartas {

        private int rango = 0;
        private int tipos = 0;

        public Cartas(int r, int t){

            rango=r;
            tipos=t;

        }
        public int getRango(){

            return rango;
        }
        public int getTipos(){

            return tipos;
        }
        public boolean rankIsLessThan(Cartas c){
            boolean rangoIsLess = false;
            if (rango < c.getRango()){
                rangoIsLess = true;
            }
            return rangoIsLess;
        }
        public boolean rangoIsMoreThan(Cartas c){
            boolean rangoIsMore = false;
            if (rango > c.getRango()){
                rangoIsMore = true;
            }
            return rangoIsMore;
        }

        public boolean tiposIsLessThan(Cartas c){
            boolean tiposIsLess = false;
            if (tipos < c.getRango()){
                tiposIsLess = true;
            }
            return tiposIsLess;
        }
        public boolean tiposIsMoreThan(Cartas c){
            boolean tiposIsMore = false;
            if (tipos > c.getRango()){
                tiposIsMore = true;
            }
            return tiposIsMore;
        }

        public String toString(Cartas c){
            String tiposCarta=null;
            String rangoCarta;

            int cRango=getRango();
            int cTipos=getTipos();

            switch (cTipos){
                case 0:
                    tiposCarta="corazones";
                    break;
                case 1:
                    tiposCarta="diamantes";
                    break;
                case 2:
                    tiposCarta="treboles";
                    break;
                case 3:
                    tiposCarta="espadas";
                    break;
            }
            switch (cRango){
                case 1:
                    rangoCarta="As";
                    break;
                case 2:
                    rangoCarta="2";
                    break;
                case 3:
                    rangoCarta="3";
                    break;
                case 4:
                    rangoCarta="4";
                    break;
                case 5:
                    rangoCarta="5";
                    break;
                case 6:
                    rangoCarta="6";
                    break;
                case 7:
                    rangoCarta="7";
                    break;
                case 8:
                    rangoCarta="8";
                    break;
                case 9:
                    rangoCarta="9";
                    break;
                case 10:
                    rangoCarta="10";
                    break;
                case 11:
                    rangoCarta="Jota";
                    break;
                case 12:
                    rangoCarta="Reina";
                    break;
                case 13:
                    rangoCarta="Rey";
                    break;
                default: rangoCarta = "n/a";

            }
            String cartaString = rangoCarta + " de " + tiposCarta;

            return cartaString;
        }


    }

