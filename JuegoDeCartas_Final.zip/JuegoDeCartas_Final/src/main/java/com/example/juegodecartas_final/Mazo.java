package com.example.juegodecartas_final;

public class Mazo {
    private Cartas[] mazoC = new Cartas [52];
    private int usado;
    public Mazo (){
        mazoC = new Cartas [52];
        int cartaCT = 0;
        for (int tipos=0; tipos <=3; tipos++){
            for (int rango=1; rango<=13; rango++){
                mazoC[cartaCT]= new Cartas(rango,tipos);
                cartaCT++;
            }
        }usado=0;
    }

    public static int getRango(){
        int rango=1;
        return rango;
    };
    public static int getTipos(){
        int tipos=1;
        return tipos;
    };

    public void Barajear(){
        for (int i=51; i > 0; i--){
            int rand = (int)(Math.random()*(i+1));
            Cartas temp = mazoC[i];
            mazoC[i] = mazoC[rand];
            mazoC[rand] = temp;


        }
        usado=0;

    }

    public Cartas Reparto(){
        if (usado==52)
            Barajear();
        usado++;
        return  mazoC[usado - 1];

    }

    public void EstaVacio(){
        if (usado==52)

            System.out.println("esta vacio");
    }



}


