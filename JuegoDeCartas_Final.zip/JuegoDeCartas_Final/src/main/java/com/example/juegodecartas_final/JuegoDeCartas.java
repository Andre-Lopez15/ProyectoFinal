package com.example.juegodecartas_final;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class JuegoDeCartas extends Application {
    Label lbl1, lbl2, lblSiguiente;
    RadioButton rb1 = new RadioButton();

    RadioButton rb2 = new RadioButton();

    Button btn1, btn2;

    Label lblEstado;
    MenuBar mBar;
    Image  imgDerecha2;
    ImageView vistaDeImgDerecha;
    ProgressBar progBar;
    ProgressIndicator progIndicador;
    private Label progEtiqueta;

    public int rastro;

    Mazo mazoC;

    String mensaje;

    Cartas cart1;
    Cartas cart2;

    final Label label = new Label();

    int rastroDePuntos=0;


    public JuegoDeCartas(){

    }

    @Override
    public void init (){
        lbl1 = new Label("Primera carta repartida");
        lbl2 = new Label("Segunda carta repartida");
        lblSiguiente = new Label("La siguiente carta sera:");

        mBar = new MenuBar();

        Menu mnuArchivo = new Menu("Archivo");

        MenuItem nuevoJuego = new MenuItem("Empezar de nuevo");
        mnuArchivo.getItems().add(nuevoJuego);

        MenuItem Barajear = new MenuItem("Barajar");
        mnuArchivo.getItems().add(Barajear);

        MenuItem salida = new MenuItem("Salir del juego");
        mnuArchivo.getItems().add(salida);

        mBar.getMenus().add(mnuArchivo);

        Menu mnuAyuda = new Menu("Ayuda");

        MenuItem sobreIcono = new MenuItem("Acerca de:");
        mnuAyuda.getItems().add(sobreIcono);

        sobreIcono.setOnAction(ae -> AcercaDelDialogo());

        mBar.getMenus().add(mnuAyuda);

        progBar=new ProgressBar(0);
        progIndicador = new ProgressIndicator(0);

        nuevoJuego.setOnAction(actionEvent -> {{
            mazoC = new Mazo();
            rastroDePuntos=0;

            float progreso_actual = 0f;
            for (int i=0;i < 10; i++) {
                progreso_actual += 0.00;
                progBar.setProgress(progreso_actual);

            }
            for (int i=0;i < 10;i++){
                progreso_actual += 0.00;
                progIndicador.setProgress(progreso_actual);
            }
        }
        });

        Barajear.setOnAction(ae -> { {
            mazoC.Barajear();

            return;
        }
        });

        salida.setOnAction(actionEvent -> { {

            javafx.application.Platform.exit();
        }});

    }

    private void AcercaDelDialogo(){
        Stage dialogo = new Stage();
        dialogo.setWidth(250);
        dialogo.setHeight(180);
        dialogo.setTitle("Acerca de:");

        Label lblSobre = new Label("Evita jugar en exceso");
        Button btnOK = new Button("OK");

        btnOK.setOnAction(ae -> dialogo.close());
        btnOK.setMinWidth(120);

        VBox vbSobre = new VBox();
        BorderPane dlgBP = new BorderPane();
        dlgBP.setCenter(btnOK);

        BorderPane bpLbl = new BorderPane();
        bpLbl.setCenter(lblSobre);

        vbSobre.setPadding(new Insets(40));
        vbSobre.setSpacing(20);

        vbSobre.getChildren().add(bpLbl);
        vbSobre.getChildren().add(dlgBP);

        Scene dlgEscena = new Scene(vbSobre);

        dialogo.setScene(dlgEscena);
        dialogo.show();

    }

    @Override
    public void start(Stage pEtapa) throws Exception {
        pEtapa.setTitle("Juego de cartas");

        pEtapa.setWidth(600);
        pEtapa.setHeight(400);


        lbl1 = new Label("Primera carta repartida");
        lbl2 = new Label("Segunda carta repartida");
        lblSiguiente = new Label("La siguiente carta sera:");
        progEtiqueta = new Label("Progreso");

        btn1 = new Button("<- Primera carta repartida");
        btn2 =  new Button("Segunda carta repartida->");

        btn1.setMaxWidth(200);
        btn2.setMaxWidth(200);

        ToggleGroup grupo = new ToggleGroup();
        RadioButton rb1 = new RadioButton("Mayor");
        rb1.setToggleGroup(grupo);
        rb1.setSelected(true);
        RadioButton rb2 = new RadioButton("Menor");
        rb2.setToggleGroup(grupo);

        mazoC=new Mazo();
        mazoC.Barajear();

        BorderPane bpPrincipal = new BorderPane();

        btn2.setDisable(true);

        bpPrincipal.setTop(mBar);

        VBox panel = new VBox();

        panel.getChildren().add(lblSiguiente);
        panel.getChildren().add(rb1);
        panel.getChildren().add(rb2);
        panel.getChildren().add(btn1);
        panel.getChildren().add(btn2);
        panel.getChildren().add(label);
        panel.getChildren().add(progEtiqueta);
        panel.getChildren().addAll(progBar, progIndicador);

        panel.setAlignment(Pos.CENTER);
        panel.setSpacing(10);

        BorderPane.setAlignment(panel, Pos.CENTER);
        BorderPane.setMargin(panel, new Insets(40,12,12,15));
        bpPrincipal.setCenter(panel);

        VBox panel2 = new VBox();
        Image img = new Image("file:cards/cards.png");
        ImageView imgVista = new ImageView(img);
        panel2.getChildren().add(imgVista);
        panel2.getChildren().add(lbl1);

        BorderPane.setAlignment(panel2, Pos.TOP_LEFT);
        BorderPane.setMargin(panel2, new Insets(12,12,12,12));
        bpPrincipal.setLeft(panel2);

        pEtapa.resizableProperty().setValue(Boolean.FALSE);

        VBox panel3 = new VBox();




        Image img2 = new Image("file:cards/cards.png");
        ImageView imgVista2 = new ImageView(img2);
        panel3.getChildren().add(lbl2);
        panel2.getChildren().add(imgVista2);

        BorderPane.setAlignment(panel3, Pos.TOP_RIGHT);
        BorderPane.setMargin(panel3, new Insets(12,12,12,12));
        bpPrincipal.setRight(panel3);

        Scene s = new Scene(bpPrincipal);
        pEtapa.setScene(s);

        btn1.setOnAction(actionEvent -> {{
            panel2.getChildren().clear();
            panel2.getChildren().add(lbl1);

            btn2.setDisable(false);

            Cartas cart1 = mazoC.Reparto();

            mazoC.EstaVacio();

            rastro = cart1.getRango();

            Image img3 = new Image("file:cards/"+ cart1.toString(cart1)+".png");
            System.out.println("Carta izquierda repartida"+ " "+ cart1.toString(cart1));
            ImageView imgVista3 = new ImageView(img3);

            panel2.getChildren().add(imgVista3);
            panel3.getChildren().clear();
            panel3.getChildren().add(imgVista2);

            BorderPane.setAlignment(panel2, Pos.TOP_LEFT);
            BorderPane.setMargin(panel2, new Insets(12,12,12,12));
            bpPrincipal.setLeft(panel2);
            btn1.setDisable(true);





        }});

        btn2.setOnAction(actionEvent -> {{
            panel3.getChildren().clear();
            panel3.getChildren().add(lbl2);

            btn1.setDisable(false);

            Cartas cart2 = mazoC.Reparto();

            mazoC.EstaVacio();

            Image img3 = new Image("file:cards/"+ cart2.toString(cart2)+".png");
            System.out.println("Carta derecha repartida" + " " + cart2.toString(cart2));
            ImageView imgVista5 = new ImageView(img3);
            panel3.getChildren().add(imgVista5);
            BorderPane.setAlignment(panel3, Pos.TOP_RIGHT );
            BorderPane.setMargin(panel3, new Insets(12,12,12,12));
            bpPrincipal.setRight(panel3);

            btn2.setDisable(true);
            double progValor = progBar.progressProperty().get();

            int rango2 = cart2.getRango();

            if (rb1.isSelected() && rastro > rango2){
                label.setText("Error la carta siguiente era menor");
            }
            if (rb1.isSelected() && rastro < rango2){
                label.setText("Correcto la carta siguiente era mayor");
                progValor = progValor + 0.25;
                rastroDePuntos++;



            }

            if (rb2.isSelected() && rastro > rango2){
                label.setText("Correcto la carta siguiente era menor");
                progValor = progValor + 0.25;
                rastroDePuntos++;
            }

            if (rb2.isSelected() && rastro< rango2){
                label.setText("Error la carta siguiente era mayor");

            }

            if (rastroDePuntos==5){
                label.setText("Felicidades ganaste!!!!");
                rastroDePuntos=0;
            }
            else if (rb2.isSelected() && rastro == rango2){
                label.setText("Estas cartas son iguales");
            }
            if (progValor>=0.7){
                progBar.setStyle("-fx-accent: red;");
                progIndicador.setStyle("-fx-accent: red;");
            } else
            {
                progBar.setStyle("-fx-accent: green;");
                progIndicador.setStyle("-fx-accent: green;");
            }

            if (progValor<0.95){
                progBar.setProgress(progValor);
                progIndicador.setProgress(progValor);
            }
            else
            {
                progValor=1;
                progBar.setProgress(progValor);
                progIndicador.setProgress(progValor);
            }

        }});

        pEtapa.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
