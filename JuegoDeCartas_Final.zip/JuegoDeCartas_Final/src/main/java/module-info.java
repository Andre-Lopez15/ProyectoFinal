module com.example.juegodecartas_final {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.juegodecartas_final to javafx.fxml;
    exports com.example.juegodecartas_final;
}